# Azure Deployment Guide for SQL Writeback Middleware

This guide will help you deploy your Node.js SQL Writeback Middleware to Azure. You'll deploy from this PC, and then use the middleware from Power BI running on another PC.

## Overview
Your middleware provides CRUD operations for Power BI SQL Writeback Visual:
- **Insert**: `/insert` - Add new records
- **Update**: `/update` - Modify existing records  
- **Delete**: `/delete` - Remove records
- **Batch Insert**: `/batch-insert` - Add multiple records at once

## Prerequisites

1. **Azure CLI installed** on this deployment PC
2. **Azure subscription**: `e4efb5f5-d284-4dd7-9709-cfcd7a21c932`
3. **Resource Group**: `YOUR_RESOURCE_GROUP` (configure as needed)
4. **SQL Server database** accessible from Azure
5. **Docker** (optional, for local testing)

## Deployment Options

### Option 1: Azure Container Apps (Recommended)
✅ **Best for**: Serverless, auto-scaling, cost-effective
✅ **Similar to**: Google Cloud Run (your previous deployment)

### Option 2: Azure App Service - Free Tier (Budget-friendly)
✅ **Best for**: Testing, development, low-cost hosting
✅ **App Name**: `sqlwriteback`
✅ **Cost**: Free tier (F1 SKU)

### Option 3: Azure App Service - Standard
✅ **Best for**: Traditional web app hosting, always-on applications

## Quick Deployment Steps

### 1. Install Azure CLI (if not installed)
```bash
# macOS
brew install azure-cli

# Verify installation
az --version
```

### 2. Login to Azure
```bash
az login
```

### 3a. Deploy using Azure Container Apps (Recommended)
```bash
# Run the deployment script
./deploy-azure-container-apps.sh
```

### 3b. Deploy using Azure Free Web App (Budget-friendly)
```bash
# Run the free tier deployment script
./deploy-azure-free-webapp.sh
```

### 4. Database Configuration (Pre-configured)
Your database connection is already configured in the deployment scripts:

- **Server**: `YOUR_DB_SERVER`
- **Database**: `YOUR_DB_DATABASE`
- **Username**: `YOUR_DB_USERNAME`
- **Password**: `YOUR_DB_PASSWORD`
- **Default Table**: `DBO.RebatePeriodN`

The deployment script will automatically set these as secure secrets in Azure.

## Configuration for Power BI (Other PC)

Once deployed, you'll get a URL like: `https://sql-writeback-middleware.region.azurecontainerapps.io`

### Power BI Configuration
On your Power BI PC, configure the SQL Writeback Visual with:

**Base URL**: `https://your-app-name.region.azurecontainerapps.io`

**Endpoints**:
- Insert: `POST /insert`
- Update: `POST /update` 
- Delete: `POST /delete`
- Batch Insert: `POST /batch-insert`

**Request Format** (for your database):
```json
{
  "username": "YOUR_DB_USERNAME",
  "password": "YOUR_DB_PASSWORD", 
  "server": "YOUR_DB_SERVER",
  "database": "YOUR_DB_DATABASE",
  "tableName": "DBO.RebatePeriodN",
  "data": { /* your data */ },
  "whereClause": { /* for updates/deletes */ }
}
```

## Security Considerations

1. **HTTPS**: All traffic is encrypted (Azure provides SSL certificates)
2. **CORS**: Configured to allow Power BI origins
3. **Environment Variables**: Database credentials stored as secrets
4. **Network**: Ensure your SQL Server allows Azure connections

## Testing Your Deployment

### Health Check
```bash
curl https://your-app-url.azurecontainerapps.io/health
```

### Test Insert (with your database)
```bash
curl -X POST https://your-app-url.azurecontainerapps.io/insert \
  -H "Content-Type: application/json" \
  -d '{
    "username": "YOUR_DB_USERNAME",
    "password": "YOUR_DB_PASSWORD",
    "server": "YOUR_DB_SERVER",
    "database": "YOUR_DB_DATABASE",
    "tableName": "YOUR_TABLE_NAME",
    "data": {"YourField": "TestValue"}
  }'
```

## Monitoring and Logs

### View Logs
```bash
az containerapp logs show \
  --name sql-writeback-middleware \
  --resource-group Qlikbate \
  --follow
```

### Monitor Performance
- Use Azure Portal → Container Apps → your app → Metrics
- Check CPU, Memory, Request count, Response times

## Updating Your App

### Method 1: Rebuild and Deploy
```bash
# Build new image
az acr build --registry acrsqlmiddleware --image sql-writeback-middleware:latest .

# Update container app
az containerapp update \
  --name sql-writeback-middleware \
  --resource-group Qlikbate \
  --image acrsqlmiddleware.azurecr.io/sql-writeback-middleware:latest
```

### Method 2: GitHub Actions (Automated)
Push changes to your GitHub repository main branch - the workflow will automatically deploy.

## Troubleshooting

### Common Issues:

1. **Connection Timeout**: Check SQL Server firewall allows Azure IPs
2. **Authentication Failed**: Verify database credentials in secrets
3. **CORS Errors**: Ensure your Power BI domain is allowed
4. **Port Issues**: Azure automatically maps to port 8080 (configured in Dockerfile)

### Debug Steps:
1. Check application logs: `az containerapp logs show...`
2. Test health endpoint: `/health`
3. Verify environment variables are set
4. Check SQL Server connectivity from Azure

## Cost Optimization

- **Azure Container Apps**: Pay only when requests are processed (serverless)
- **Scaling**: Configured 0-10 replicas (scales to zero when idle)
- **Resources**: 0.5 CPU, 1GB RAM (adjust if needed)

## Clean Up Resources

To avoid charges when not needed:
```bash
az group delete --name Qlikbate --yes --no-wait
```

⚠️ **Warning**: This will delete your entire `Qlikbate` resource group and all resources in it!

## Support

- Check application logs for errors
- Monitor Azure Portal for resource health
- Test endpoints with curl or Postman
- Verify SQL Server connectivity

---

**Next Steps**:
1. Deploy using the scripts provided
2. Configure database secrets  
3. Test the health endpoint
4. Configure Power BI to use your new Azure URL
5. Test CRUD operations from Power BI

Your middleware will be accessible from any PC with internet access, including your Power BI machine!
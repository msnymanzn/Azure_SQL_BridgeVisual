#!/bin/bash

# Test script for QlikbateDB RebatePeriodN table
# Replace YOUR_APP_URL with the actual URL you get after deployment

if [ -z "$1" ]; then
    echo "Usage: ./test-qlikbate.sh YOUR_APP_URL"
    echo "Example: ./test-qlikbate.sh https://sqlwriteback.azurewebsites.net"
    echo "Example: ./test-qlikbate.sh https://sql-writeback-middleware.region.azurecontainerapps.io"
    exit 1
fi

APP_URL=$1

echo "🧪 Testing SQL Writeback Middleware for QlikbateDB..."
echo "🌐 Using URL: $APP_URL"
echo ""

# Test health check
echo "1️⃣ Testing health check..."
curl -s "$APP_URL/health" | jq . || echo "Health check failed"
echo ""

# Test insert
echo "2️⃣ Testing insert to RebatePeriodN table..."
curl -X POST "$APP_URL/insert" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "YOUR_DB_USERNAME",
    "password": "YOUR_DB_PASSWORD",
    "server": "YOUR_DB_SERVER",
    "database": "YOUR_DB_DATABASE",
    "tableName": "DBO.RebatePeriodN",
    "data": {
      "Submission ID": "TEST001"
    }
  }' \
  --max-time 60 | jq . || echo "Insert test failed"
echo ""

echo "✅ Testing complete!"
echo ""
echo "💡 To test from Power BI, use:"
echo "   Base URL: $APP_URL"
echo "   Endpoints: /insert, /update, /delete, /batch-insert"
echo "   Table: DBO.RebatePeriodN"
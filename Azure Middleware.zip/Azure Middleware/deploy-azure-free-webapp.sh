#!/bin/bash

# Azure App Service Deployment Script (Free Tier - Code Deployment)
# This script deploys the Node.js app directly without containers for free tier compatibility

set -e

# Configuration
SUBSCRIPTION_ID="e4efb5f5-d284-4dd7-9709-cfcd7a21c932"
RESOURCE_GROUP="Qlikbate"
LOCATION="southafricanorth"
APP_SERVICE_PLAN="plan-sqlwriteback-free"
WEB_APP_NAME="sqlwriteback"

echo "🚀 Starting Azure App Service deployment (Free Tier)..."

# Set subscription
echo "🔧 Setting Azure subscription..."
az account set --subscription $SUBSCRIPTION_ID

# Create resource group (if it doesn't exist)
echo "📦 Ensuring resource group exists..."
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION

# Create App Service Plan (Free Tier)
echo "📋 Creating App Service Plan (Free Tier)..."
az appservice plan create \
  --name $APP_SERVICE_PLAN \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --is-linux \
  --sku F1

# Create Web App (Node.js)
echo "🌐 Creating Web App..."
az webapp create \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --plan $APP_SERVICE_PLAN \
  --runtime "NODE|20-lts"

# Configure app settings
echo "⚙️ Configuring app settings..."
az webapp config appsettings set \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --settings \
    PORT=8080 \
    WEBSITES_PORT=8080 \
    SCM_DO_BUILD_DURING_DEPLOYMENT=true \
    DB_USER="YOUR_DB_USERNAME" \
    DB_PASSWORD="YOUR_DB_PASSWORD" \
    DB_SERVER="YOUR_DB_SERVER" \
    DB_DATABASE="YOUR_DB_DATABASE"

# Deploy code using zip deployment
echo "📦 Preparing deployment package..."
zip -r deployment.zip . -x "*.git*" "node_modules/*" "*.DS_Store" "deploy-*.sh" "test-*.sh" "*.md" "Dockerfile" ".dockerignore" "containerapp.yaml" ".github/*"

echo "🚀 Deploying application..."
az webapp deployment source config-zip \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --src deployment.zip

# Clean up deployment file
rm deployment.zip

# Enable logging
echo "📝 Enabling application logging..."
az webapp log config \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --application-logging filesystem \
  --level information

# Get the app URL
APP_URL=$(az webapp show \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "defaultHostName" \
  --output tsv)

echo ""
echo "✅ Deployment complete!"
echo "🌐 Your app is available at: https://$APP_URL"
echo "🔍 Health check: https://$APP_URL/health"
echo ""
echo "✅ Database connection configured for:"
echo "   Server: YOUR_DB_SERVER"
echo "   Database: YOUR_DB_DATABASE"
echo "   Table: DBO.RebatePeriodN"
echo ""
echo "💡 App Name: $WEB_APP_NAME"
echo "💰 Tier: Free (F1)"
echo ""
echo "📝 To view logs:"
echo "az webapp log tail --name $WEB_APP_NAME --resource-group $RESOURCE_GROUP"
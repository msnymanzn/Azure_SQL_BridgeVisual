#!/bin/bash

# Azure App Service Deployment Script
# Make sure you're logged in to Azure CLI: az login

set -e

# Configuration
SUBSCRIPTION_ID="e4efb5f5-d284-4dd7-9709-cfcd7a21c932"
RESOURCE_GROUP="Qlikbate"
LOCATION="eastus"
APP_SERVICE_PLAN="plan-sqlwriteback-free"
WEB_APP_NAME="sqlwriteback"
ACR_NAME="acrsqlwriteback"
IMAGE_NAME="sql-writeback-middleware"

echo "🚀 Starting Azure App Service deployment..."

# Set subscription
echo "🔧 Setting Azure subscription..."
az account set --subscription $SUBSCRIPTION_ID

# Create resource group (if it doesn't exist)
echo "📦 Ensuring resource group exists..."
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION

# Create Azure Container Registry
echo "🐳 Creating Azure Container Registry..."
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Basic \
  --admin-enabled true

# Get ACR credentials
ACR_LOGIN_SERVER=$(az acr show --name $ACR_NAME --resource-group $RESOURCE_GROUP --query "loginServer" --output tsv)
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --resource-group $RESOURCE_GROUP --query "username" --output tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --resource-group $RESOURCE_GROUP --query "passwords[0].value" --output tsv)

# Build and push Docker image
echo "🔨 Building and pushing Docker image..."
az acr build \
  --registry $ACR_NAME \
  --image $IMAGE_NAME:latest \
  .

# Create App Service Plan (Free Tier)
echo "📋 Creating App Service Plan (Free Tier)..."
az appservice plan create \
  --name $APP_SERVICE_PLAN \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --is-linux \
  --sku F1

# Create Web App
echo "🌐 Creating Web App..."
az webapp create \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --plan $APP_SERVICE_PLAN \
  --deployment-container-image-name $ACR_LOGIN_SERVER/$IMAGE_NAME:latest

# Configure container registry credentials
echo "🔐 Configuring container registry..."
az webapp config container set \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --docker-custom-image-name $ACR_LOGIN_SERVER/$IMAGE_NAME:latest \
  --docker-registry-server-url https://$ACR_LOGIN_SERVER \
  --docker-registry-server-user $ACR_USERNAME \
  --docker-registry-server-password $ACR_PASSWORD

# Configure app settings
echo "⚙️ Configuring app settings..."
az webapp config appsettings set \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --settings \
    PORT=8080 \
    WEBSITES_PORT=8080 \
    WEBSITES_CONTAINER_START_TIME_LIMIT=1800 \
    DB_USER="Clappia" \
    DB_PASSWORD="Cl@ppia2025!Secure" \
    DB_SERVER="qlikbate.database.windows.net" \
    DB_DATABASE="QlikbateDB"

# Enable container logging
echo "📝 Enabling container logging..."
az webapp log config \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --docker-container-logging filesystem

# Get the app URL
APP_URL=$(az webapp show \
  --name $WEB_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "defaultHostName" \
  --output tsv)

echo ""
echo "✅ Deployment complete!"
echo "🌐 Your app is available at: https://$APP_URL"
echo "🔍 Health check: https://$APP_URL/health"
echo ""
echo "✅ Database connection configured for:"
echo "   Server: qlikbate.database.windows.net"
echo "   Database: QlikbateDB"
echo "   Table: DBO.RebatePeriodN"
#!/bin/bash

# Azure Container Apps Deployment Script
# Make sure you're logged in to Azure CLI: az login

set -e

# Configuration
SUBSCRIPTION_ID="e4efb5f5-d284-4dd7-9709-cfcd7a21c932"
RESOURCE_GROUP="Qlikbate"
LOCATION="eastus"
CONTAINER_APP_ENV="env-sql-middleware"
CONTAINER_APP_NAME="sql-writeback-middleware"
ACR_NAME="acrsqlmiddleware"
IMAGE_NAME="sql-writeback-middleware"

echo "🚀 Starting Azure Container Apps deployment..."

# Set subscription
echo "🔧 Setting Azure subscription..."
az account set --subscription $SUBSCRIPTION_ID

# Create resource group (if it doesn't exist)
echo "📦 Ensuring resource group exists..."
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION

# Create Azure Container Registry
echo "🐳 Creating Azure Container Registry..."
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Basic \
  --admin-enabled true

# Get ACR login server
ACR_LOGIN_SERVER=$(az acr show --name $ACR_NAME --resource-group $RESOURCE_GROUP --query "loginServer" --output tsv)

# Build and push Docker image
echo "🔨 Building and pushing Docker image..."
az acr build \
  --registry $ACR_NAME \
  --image $IMAGE_NAME:latest \
  .

# Create Container Apps environment
echo "🌐 Creating Container Apps environment..."
az containerapp env create \
  --name $CONTAINER_APP_ENV \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION

# Create the container app
echo "🚢 Creating container app..."
az containerapp create \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_APP_ENV \
  --image $ACR_LOGIN_SERVER/$IMAGE_NAME:latest \
  --target-port 8080 \
  --ingress external \
  --registry-server $ACR_LOGIN_SERVER \
  --min-replicas 0 \
  --max-replicas 10 \
  --cpu 0.5 \
  --memory 1Gi \
  --env-vars \
    PORT=8080 \
    DB_USER=secretref:db-user \
    DB_PASSWORD=secretref:db-password \
    DB_SERVER=secretref:db-server \
    DB_DATABASE=secretref:db-database

echo "🔐 Setting up database secrets..."
az containerapp secret set \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --secrets \
    db-user="YOUR_DB_USERNAME" \
    db-password="YOUR_DB_PASSWORD" \
    db-server="YOUR_DB_SERVER" \
    db-database="YOUR_DB_DATABASE"

echo "✅ Database secrets configured successfully!"

# Get the app URL
APP_URL=$(az containerapp show \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "properties.configuration.ingress.fqdn" \
  --output tsv)

echo ""
echo "✅ Deployment complete!"
echo "🌐 Your app is available at: https://$APP_URL"
echo "🔍 Health check: https://$APP_URL/health"
echo ""
echo "Don't forget to set your database secrets using the commands above!"
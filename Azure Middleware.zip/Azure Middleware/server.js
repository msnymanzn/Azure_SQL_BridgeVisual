const express = require('express');
const cors = require('cors');
const sql = require('mssql');
const app = express();

// Logging utility
const logger = {
    info: (message, data = {}) => {
        console.log(`${new Date().toISOString()} - INFO: ${message}`);
        if (Object.keys(data).length > 0) console.log(JSON.stringify(data, null, 2));
    },
    error: (message, error) => {
        console.error(`${new Date().toISOString()} - ERROR: ${message}`);
        if (error) console.error(error.stack || error);
    }
};

// SQL type mapping
const SQL_TYPE_MAP = {
    bigint: sql.BigInt,
    int: sql.Int,
    smallint: sql.SmallInt,
    tinyint: sql.TinyInt,
    decimal: sql.Decimal,
    numeric: sql.Numeric,
    float: sql.Float,
    real: sql.Real,
    money: sql.Money,
    smallmoney: sql.SmallMoney,
    bit: sql.Bit,
    char: sql.Char,
    varchar: sql.VarChar,
    nchar: sql.NChar,
    nvarchar: sql.NVarChar,
    text: sql.Text,
    ntext: sql.NText,
    date: sql.Date,
    datetime: sql.DateTime,
    datetime2: sql.DateTime2,
    datetimeoffset: sql.DateTimeOffset,
    time: sql.Time,
    binary: sql.Binary,
    varbinary: sql.VarBinary,
    image: sql.Image,
    uniqueidentifier: sql.UniqueIdentifier,
    xml: sql.Xml
};

// Configure CORS
app.use(cors({ origin: true, credentials: true, methods: ['GET', 'POST'], allowedHeaders: ['Content-Type', 'Authorization'], maxAge: 86400 }));
app.use(express.json());

// Request timeout
app.use((req, res, next) => {
    res.setTimeout(30000, () => res.status(408).json({ error: 'Request timeout' }));
    next();
});

// Request logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    if (req.body) {
        const sanitizedBody = { ...req.body };
        delete sanitizedBody.password;
        console.log('Request body:', JSON.stringify(sanitizedBody, null, 2));
    }
    next();
});

// Health check endpoint
app.get('/', (req, res) => {
    res.status(200).json({ 
        status: 'healthy', 
        service: 'SQL Writeback Middleware',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        source: 'Power BI Service Test'
    });
});

app.get('/health', (req, res) => {
    res.status(200).json({ 
        status: 'healthy', 
        service: 'SQL Writeback Middleware',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Simple test endpoint for Power BI Service
app.get('/test', (req, res) => {
    res.status(200).json({ 
        message: 'Power BI Service can reach this endpoint!',
        timestamp: new Date().toISOString(),
        middleware: 'Working'
    });
});

// CORS preflight for all endpoints
app.options('*', (req, res) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.sendStatus(200);
});

// Connection configuration
const getConnectionConfig = (settings) => ({
    user: settings.username,
    password: settings.password,
    server: settings.server,
    database: settings.database,
    options: { encrypt: true, trustServerCertificate: true, connectTimeout: 30000, enableArithAbort: true },
    pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
});

// Create pool
async function createPool(settings) {
    const config = getConnectionConfig(settings);
    return await new sql.ConnectionPool(config).connect();
}

// Helper to get table columns
async function getTableColumns(pool, schema, tableName) {
    const result = await pool.request()
        .input('schema', sql.NVarChar, schema)
        .input('table', sql.NVarChar, tableName)
        .query(`
            SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, CHARACTER_MAXIMUM_LENGTH
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = @schema AND TABLE_NAME = @table
            ORDER BY ORDINAL_POSITION;
        `);
    return result.recordset;
}

// --- CRUD Endpoints ---
// Insert
app.post('/insert', async (req, res) => {
    try {
        const pool = await createPool(req.body);
        const [schema, table] = req.body.tableName.includes('.') ? req.body.tableName.split('.') : ['dbo', req.body.tableName];
        const request = pool.request();
        const columns = [], values = [];

        Object.entries(req.body.data).forEach(([key, value], index) => {
            // Use brackets for column names and sanitized parameter names
            columns.push(`[${key}]`);
            const paramName = `param${index}`;
            values.push(`@${paramName}`);
            request.input(paramName, value);
        });

        const query = `INSERT INTO [${schema}].[${table}] (${columns.join(', ')}) VALUES (${values.join(', ')})`;
        console.log('Executing query:', query);
        await request.query(query);
        res.json({ success: true });
    } catch (error) {
        console.error('Insert error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update
app.post('/update', async (req, res) => {
    try {
        const pool = await createPool(req.body);
        const [schema, table] = req.body.tableName.includes('.') ? req.body.tableName.split('.') : ['dbo', req.body.tableName];
        const updates = [], request = pool.request();

        Object.entries(req.body.data).forEach(([key, value], index) => {
            const paramName = `set_param${index}`;
            updates.push(`[${key}] = @${paramName}`);
            request.input(paramName, value);
        });

        Object.entries(req.body.whereClause).forEach(([key, value], index) => {
            const paramName = `where_param${index}`;
            request.input(paramName, value);
        });

        const whereConditions = Object.keys(req.body.whereClause).map((key, index) => `[${key}] = @where_param${index}`);
        const query = `
            UPDATE [${schema}].[${table}] SET ${updates.join(', ')}
            WHERE ${whereConditions.join(' AND ')};
            SELECT @@ROWCOUNT as affected;
        `;

        console.log('Executing update query:', query);
        const result = await request.query(query);
        res.json({ success: true, rowsAffected: result.recordset[0].affected });
    } catch (error) {
        console.error('Update error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Delete
app.post('/delete', async (req, res) => {
    try {
        const pool = await createPool(req.body);
        const [schema, table] = req.body.tableName.includes('.') ? req.body.tableName.split('.') : ['dbo', req.body.tableName];
        const request = pool.request();

        const whereConditions = [];
        Object.entries(req.body.whereClause).forEach(([key, value], index) => {
            const paramName = `where_param${index}`;
            whereConditions.push(`[${key}] = @${paramName}`);
            request.input(paramName, value);
        });

        const query = `DELETE FROM [${schema}].[${table}] WHERE ${whereConditions.join(' AND ')}`;
        console.log('Executing delete query:', query);
        await request.query(query);
        res.json({ success: true });
    } catch (error) {
        console.error('Delete error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Batch insert
app.post('/batch-insert', async (req, res) => {
    try {
        const pool = await createPool(req.body);
        const [schema, table] = req.body.tableName.includes('.') ? req.body.tableName.split('.') : ['dbo', req.body.tableName];
        const records = req.body.data;
        const columnNames = Object.keys(records[0]);
        const request = pool.request();
        const valuesClauses = [];

        records.forEach((record, i) => {
            const rowParams = columnNames.map((col, j) => {
                const paramName = `p${i}_${j}`;
                request.input(paramName, record[col]);
                return `@${paramName}`;
            });
            valuesClauses.push(`(${rowParams.join(', ')})`);
        });

        const query = `INSERT INTO [${schema}].[${table}] (${columnNames.map(n => `[${n}]`).join(', ')}) VALUES ${valuesClauses.join(', ')}`;
        await request.query(query);
        res.json({ success: true, recordsAffected: records.length });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Start server
const port = process.env.PORT || 8080; // Default to 8080 if PORT not set
app.listen(port, '0.0.0.0', () => {
    console.log(`Middleware server running on port ${port}`);
});
